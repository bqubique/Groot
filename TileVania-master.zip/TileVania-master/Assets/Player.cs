﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Player : MonoBehaviour
{
    [SerializeField] float runSpeed = 1.0f;
    public Rigidbody2D rigidbody;
    int jumpcount = 0;

    private void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
    }
    // Update is called once per frame
    void Update()
    {
        Run();
        FlipSprite();
        Jump();
    }
    
    void Run()
    {
        float controlThrow = Input.GetAxis("Horizontal");
        Vector2 playerVelocity = new Vector2(controlThrow*runSpeed, rigidbody.velocity.y);
        rigidbody.velocity = playerVelocity;
        
    }

    void Jump()
    {
        if (Input.GetKeyDown(KeyCode.W) && jumpcount != 2|| Input.GetKeyDown(KeyCode.UpArrow) && jumpcount != 2)
        {
            rigidbody.AddForce(new Vector2(0, 7), ForceMode2D.Impulse);
            jumpcount++;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        jumpcount = 0;
    }

        void FlipSprite()
    {
        if (Input.GetAxis("Horizontal") < 0)
        {

            //transform.localScale = new Vector2(Mathf.Sign(rigidbody.velocity.x), transform.localScale.y);
        }
    }
}
